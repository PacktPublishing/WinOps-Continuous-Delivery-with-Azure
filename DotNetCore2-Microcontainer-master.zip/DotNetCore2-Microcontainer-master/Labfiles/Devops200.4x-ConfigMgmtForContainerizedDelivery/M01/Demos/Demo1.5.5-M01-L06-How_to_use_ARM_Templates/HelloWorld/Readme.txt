Run .\deploy.ps1 to see hello world.
